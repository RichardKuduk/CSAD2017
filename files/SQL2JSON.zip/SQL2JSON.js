window.onload=function(){
	getAjaxData();
}
var xmlhttp;

function getAjaxData()
{	
	if (window.XMLHttpRequest)
	{
		// IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange = showXMLData;		
	xmlhttp.open("GET", "SQL2JSON.php", true);		
	xmlhttp.send();	
}

function showXMLData()
{
	if (xmlhttp.readyState==4 && xmlhttp.status==200)	{				
		alert(xmlhttp.responseText);		
		var data = JSON.parse(xmlhttp.responseText);		
		var output = '<ul>';                     
		for (var i = 0; i < data.artists.length; i++) {			
			output += '<li>' + data.artists[i].artist_name + '</li>';
		}
		output += '</ul>';
		document.getElementById("myDiv").innerHTML = output;            
	}
}
